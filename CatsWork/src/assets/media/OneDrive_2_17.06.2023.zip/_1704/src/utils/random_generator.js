export function randomColor() {
  // const red = Math.floor(Math.random() * 256);
  // const green = Math.floor(Math.random() * 256);
  // const blue = Math.floor(Math.random() * 256);

  // return `rgb(${red}, ${green}, ${blue})`;
  return `#${Math.floor(Math.random() * 16777215).toString(16)}`;
}

export function randNumber(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}
