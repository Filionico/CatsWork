import React from "react";

// ({ name, lastName }) — извлекаем пропсы
const Writer = ({ name, lastName }) => {
  return (
    <>
      <div style={{ borderBottom: "2px dotted", padding: "7px" }}>
        {name} {lastName}
      </div>
    </>
  );
};

export default Writer;
