export const styles = {
  inputContainer: {
    display: "flex",
    justifyContent: "space-around",
    marginTop: "20px",
  },
};
