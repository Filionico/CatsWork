import logo from "../../logo.svg";
import "./App.css";

import React, { useState, useEffect } from "react";
import Writer from "../WriterMap/Writer";
import WriterList from "../WriterMap/WriterList";
import InputField from "../WriterMap/InputField";

import { randomColor, randNumber } from "../../utils/random_generator";

const names = ["John", "Jane", "Bob", "Alice", "Tom"];
const surnames = ["Smith", "Johnson", "Williams", "Brown", "Davis"];

let writers = [
  { name: "Dan", lastName: "Brown" },
  { name: "Joanne", lastName: "Rowling" },
  { name: "Stephen", lastName: "King" },
];

const App = () => {
  const [writersState, setWriters] = useState(writers);

  ////при инициализации компонента — добавить в массив объектов
  ///5 рандомных объектов с 2 парами ключ-значение
  useEffect(() => {
    for (let i = 0; i < 5; i++) {
      const name = names[randNumber(0, names.length)];
      const surname = surnames[randNumber(0, surnames.length)];

      AddToArray(`${name} ${surname}`);
    }

    console.log("Component has mounted!");
  }, []);
  ////сработает два раза, если в index.js <React.StrictMode>

  //метод добавления в массив объектов нового объекта
  const AddToArray = (newItem) => {
    let [name = "—", lastName = "—"] = newItem.split(" ");    //"john doe 13" ==> ["john", "doe", "13"]

    //массив является параметром для того, чтобы взять его текущее изменённое состояние!
    setWriters((writersState) => [
      ...writersState, //распаковка массива
      {
        //добавляем новый эл-т в конец последовательности
        name: name,
        lastName: lastName,
      },
    ]);
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>

      {/* массив компоннетов без проблем встраивается в JSX в виде обычных
      друг за другом упорядоченных компонентов с данными */}
      {[
        <Writer key="w0" name={randomColor()} lastName={randomColor()} />,
        <Writer key="w1" name="133" lastName="Jo3hn" />,
      ]}

      <WriterList data={writersState} />
      <InputField onAdd={AddToArray} />
    </div>
  );
};

export default App;

// Использование стрелочной функции при изменении state внутри цикла в функциональном компоненте обеспечивает правильную область видимости (scope) для доступа к текущему значению state и предотвращает возможные ошибки, связанные с изменением состояния компонента внутри цикла.
// При использовании обычной функции внутри цикла, значение state может быть не определено или может быть неактуальным на момент выполнения функции, что может привести к непредсказуемым результатам.
// Стрелочная функция, в свою очередь, создает свою собственную область видимости и автоматически связывает значение state с текущим контекстом выполнения, что обеспечивает корректную работу кода.
